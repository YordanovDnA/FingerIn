<?php
$server = "localhost";
$username = "yordn6kl_root";
$password = "@1Levzamen!";
$dbase = "yordn6kl_logins";

$conn = new mysqli($server, $username, $password,$dbase);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  echo "Connected successfully";


?>