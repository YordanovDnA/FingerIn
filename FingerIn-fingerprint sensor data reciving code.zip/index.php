<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    include_once('config.php');
    $sql = "SELECT * FROM logins";
    $result = $conn->query($sql);
    echo "<h2 class='text-center'>Нова таблица</h2>";
    echo "<table>";
    
    
    echo '<th>ID</th>';
    echo '<th >Име</th>';
    if ($result->num_rows > 0 ){
        
        while($row = $result->fetch_assoc()){
            $ID = $row["ID"];
            $Name = $row["Name"];
            echo '
                <tr> 
                    <td>'.$ID.'</td>
                    <td>'.$Name.'</td>
                </tr>
            ';
        }
        echo "</table>";
    }
    else{
        echo '<div>
        Таблицата е празна
      </div></div>';
    }
    ?>
</body>
</html>