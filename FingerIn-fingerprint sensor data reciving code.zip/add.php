<?php
    include_once('config.php');
    if(isset($_GET['ID'])){
        $ID = $_GET['ID'];
        $sql = "INSERT INTO logins (ID,Name)
        VALUES ('.$ID.', 'ILIYAN')";

        if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
            }
?>